gcl <- function(semilla, a, c, m, n) {
  numeros <- numeric(n)
  numeros[1] <- semilla

  for (i in 2:n) {
    numeros[i] <- (a * numeros[i - 1] + c) %% m
  }

  return(numeros)
}


